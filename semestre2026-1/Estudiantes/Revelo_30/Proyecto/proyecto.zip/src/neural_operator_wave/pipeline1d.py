"""Centralized experiment pipeline for 1D wave FNO runs."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import UTC, datetime
import json
from pathlib import Path
import re
from typing import Any

from neural_operator_wave.dataset1d import generate_wave_dataset, save_wave_dataset
from neural_operator_wave.evaluation1d import evaluate_model
from neural_operator_wave.training1d import TrainConfig, train_model
from neural_operator_wave.visualization1d import create_prediction_visuals


@dataclass(frozen=True)
class PipelineConfig:
    """Configuration for a complete dataset/train/evaluate/visualize run."""

    run_name: str = "run"
    runs_root: Path = Path("artifacts/1d/runs")
    index_path: Path = Path("artifacts/1d/runs_index.json")
    samples: int = 256
    nx: int = 128
    nt: int = 80
    c: float = 1.0
    length: float = 1.0
    dt: float | None = None
    seed: int = 0
    epochs: int = 5
    batch_size: int = 16
    lr: float = 1e-3
    width: int = 32
    modes: int = 12
    layers: int = 4
    val_fraction: float = 0.2
    device: str = "auto"
    eval_split: str = "val"
    sample_index: int = 0


@dataclass(frozen=True)
class RunPaths:
    """Standard paths inside one self-contained run directory."""

    run_id: str
    run_name: str
    run_dir: Path
    config: Path
    summary: Path
    dataset: Path
    checkpoint: Path
    metrics: Path
    loss_history: Path
    plots_dir: Path
    animations_dir: Path


def utc_now_iso() -> str:
    """Return a UTC timestamp suitable for metadata JSON."""
    return datetime.now(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def slugify_run_name(name: str | None) -> str:
    """Convert a user-facing run name into a stable path component."""
    raw = (name or "run").strip().lower()
    slug = re.sub(r"[^a-z0-9]+", "_", raw).strip("_")
    return slug or "run"


def allocate_run_paths(runs_root: str | Path, run_name: str | None) -> RunPaths:
    """Create and return the next available run directory without overwriting."""
    root = Path(runs_root)
    root.mkdir(parents=True, exist_ok=True)
    slug = slugify_run_name(run_name)
    next_number = _next_run_number(root)

    while True:
        run_id = f"{next_number:03d}_{slug}"
        run_dir = root / run_id
        try:
            run_dir.mkdir(exist_ok=False)
            break
        except FileExistsError:
            next_number += 1

    return RunPaths(
        run_id=run_id,
        run_name=slug,
        run_dir=run_dir,
        config=run_dir / "config.json",
        summary=run_dir / "run_summary.json",
        dataset=run_dir / "dataset" / "wave1d.npz",
        checkpoint=run_dir / "checkpoints" / "fno1d.pt",
        metrics=run_dir / "eval" / "metrics.json",
        loss_history=run_dir / "logs" / "loss_history.json",
        plots_dir=run_dir / "plots",
        animations_dir=run_dir / "animations",
    )


def _next_run_number(runs_root: Path) -> int:
    highest = 0
    pattern = re.compile(r"^(\d{3})_")
    for child in runs_root.iterdir():
        if not child.is_dir():
            continue
        match = pattern.match(child.name)
        if match is not None:
            highest = max(highest, int(match.group(1)))
    return highest + 1


def write_json(
    path: str | Path, payload: dict[str, Any] | list[dict[str, Any]]
) -> Path:
    """Write JSON with parent creation and deterministic formatting."""
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(_jsonable(payload), indent=2) + "\n", encoding="utf-8")
    return output


def read_runs_index(index_path: str | Path) -> list[dict[str, Any]]:
    """Load the compact run index, returning an empty list if it does not exist."""
    path = Path(index_path)
    if not path.exists():
        return []
    loaded = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(loaded, list):
        raise ValueError(f"runs index must be a JSON list: {path}")
    return loaded


def update_runs_index(index_path: str | Path, record: dict[str, Any]) -> Path:
    """Append or replace one compact run-index record."""
    path = Path(index_path)
    records = [
        item for item in read_runs_index(path) if item.get("run_id") != record["run_id"]
    ]
    records.append(record)
    records.sort(key=lambda item: str(item.get("run_id", "")))
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = path.with_suffix(path.suffix + ".tmp")
    temp_path.write_text(
        json.dumps(_jsonable(records), indent=2) + "\n", encoding="utf-8"
    )
    temp_path.replace(path)
    return path


def build_run_summary(
    *,
    config: PipelineConfig,
    paths: RunPaths,
    created_at: str,
    status: str,
    checkpoint: dict[str, Any] | None = None,
    metrics: dict[str, Any] | None = None,
    visual_artifacts: list[Path] | None = None,
    error: str | None = None,
) -> dict[str, Any]:
    """Build the detailed nested metadata written to ``run_summary.json``."""
    history = checkpoint.get("history", {}) if checkpoint else {}
    train_indices = checkpoint.get("train_indices", []) if checkpoint else []
    dataset_metadata = checkpoint.get("dataset_metadata", {}) if checkpoint else {}
    eval_count = int(metrics.get("samples_evaluated", 0)) if metrics else 0
    evaluation_source = evaluation_source_for_split(config.eval_split)

    summary: dict[str, Any] = {
        "run_id": paths.run_id,
        "run_name": paths.run_name,
        "created_at": created_at,
        "status": status,
        "model_name": checkpoint.get("model_name", "FNO") if checkpoint else "FNO",
        "model_library": checkpoint.get("model_library", "neuralop")
        if checkpoint
        else "neuralop",
        "model_impl": checkpoint.get("model_impl", "neuralop.models.FNO")
        if checkpoint
        else "neuralop.models.FNO",
        "trainer_library": checkpoint.get("trainer_library", "neuralop")
        if checkpoint
        else "neuralop",
        "trainer_impl": checkpoint.get("trainer_impl", "neuralop.training.Trainer")
        if checkpoint
        else "neuralop.training.Trainer",
        "loss_impl": checkpoint.get("loss_impl", "neuralop.losses.LpLoss")
        if checkpoint
        else "neuralop.losses.LpLoss",
        "dataset": {
            "n_samples_total": int(dataset_metadata.get("samples", config.samples)),
            "n_train": len(train_indices),
            "n_eval": eval_count,
            "val_fraction": config.val_fraction,
            "nx": int(dataset_metadata.get("nx", config.nx)),
            "nt": int(dataset_metadata.get("nt", config.nt)),
            "c": float(dataset_metadata.get("c", config.c)),
            "length": float(dataset_metadata.get("length", config.length)),
            "dt": dataset_metadata.get("dt", config.dt),
            "requested_dt": config.dt,
            "dx": dataset_metadata.get("dx"),
            "boundary_condition": dataset_metadata.get("boundary_condition"),
            "seed": config.seed,
            "path": str(paths.dataset),
        },
        "training": {
            "epochs": config.epochs,
            "batch_size": config.batch_size,
            "learning_rate": config.lr,
            "width": config.width,
            "modes": config.modes,
            "layers": config.layers,
            "requested_device": config.device,
            "selected_device": checkpoint.get("selected_device")
            if checkpoint
            else None,
            "final_train_loss": final_loss(history, "train_loss", "avg_loss"),
            "final_val_loss": final_loss(history, "val_loss", "val_l2"),
            "history_path": str(paths.loss_history),
        },
        "evaluation": {
            "source": evaluation_source,
            "split": config.eval_split,
            "uses_separate_dataset": False,
            "data_path": str(paths.dataset),
            "n_eval": eval_count,
            "metrics_path": str(paths.metrics),
            "metrics": metrics or {},
        },
        "artifacts": {
            "run_dir": str(paths.run_dir),
            "config_path": str(paths.config),
            "summary_path": str(paths.summary),
            "checkpoint_path": str(paths.checkpoint),
            "plots_dir": str(paths.plots_dir),
            "animations_dir": str(paths.animations_dir),
            "visual_artifacts": [str(path) for path in visual_artifacts or []],
        },
        "config": asdict(config),
    }
    if error is not None:
        summary["error"] = error
    return summary


def build_index_record(summary: dict[str, Any]) -> dict[str, Any]:
    """Build one flat Dash-friendly record for ``runs_index.json``."""
    dataset = summary["dataset"]
    training = summary["training"]
    evaluation = summary["evaluation"]
    metrics = evaluation.get("metrics", {})
    artifacts = summary["artifacts"]
    sample_index = int(summary.get("config", {}).get("sample_index", 0))
    sample_prefix = f"sample_{sample_index:03d}"
    main_plot_path = Path(artifacts["plots_dir"]) / f"{sample_prefix}_prediction.png"
    animation_path = _first_existing_animation(
        Path(artifacts["animations_dir"]), sample_prefix
    )
    return {
        "run_id": summary["run_id"],
        "run_name": summary["run_name"],
        "created_at": summary["created_at"],
        "status": summary["status"],
        "n_samples_total": dataset["n_samples_total"],
        "n_train": dataset["n_train"],
        "n_eval": dataset["n_eval"],
        "val_fraction": dataset["val_fraction"],
        "nx": dataset["nx"],
        "nt": dataset["nt"],
        "epochs": training["epochs"],
        "batch_size": training["batch_size"],
        "learning_rate": training["learning_rate"],
        "width": training["width"],
        "modes": training["modes"],
        "layers": training["layers"],
        "model_name": summary["model_name"],
        "model_library": summary["model_library"],
        "trainer_library": summary["trainer_library"],
        "final_train_loss": training["final_train_loss"],
        "final_val_loss": training["final_val_loss"],
        "final_eval_mse": metrics.get("mse"),
        "final_eval_relative_l2": metrics.get("relative_l2"),
        "evaluation_source": evaluation["source"],
        "evaluation_split": evaluation["split"],
        "uses_separate_eval_dataset": evaluation["uses_separate_dataset"],
        "run_dir": artifacts["run_dir"],
        "summary_path": artifacts["summary_path"],
        "main_plot_path": str(main_plot_path),
        "animation_path": str(animation_path) if animation_path is not None else None,
    }


def evaluation_source_for_split(split: str) -> str:
    """Return a stable human-readable source label for an evaluation split."""
    if split == "val":
        return "validation_split"
    if split == "train":
        return "training_split"
    if split == "all":
        return "full_dataset"
    raise ValueError("eval_split must be one of: train, val, all")


def final_loss(
    history: dict[str, Any], key: str, final_metric_key: str | None = None
) -> float | None:
    """Return the last loss value for an optional loss-history series."""
    values = history.get(key, [])
    if values:
        return float(values[-1])
    if final_metric_key is None:
        return None
    final_metrics = history.get("final_trainer_metrics", {})
    value = final_metrics.get(final_metric_key)
    return float(value) if value is not None else None


def run_pipeline(config: PipelineConfig) -> dict[str, Any]:
    """Run dataset generation, training, evaluation, visualization, and indexing."""
    if not 0 <= config.sample_index < config.samples:
        raise ValueError("sample_index must be in [0, samples - 1]")
    paths = allocate_run_paths(config.runs_root, config.run_name)
    created_at = utc_now_iso()
    write_json(paths.config, asdict(config) | {"run_id": paths.run_id})

    checkpoint: dict[str, Any] | None = None
    metrics: dict[str, Any] | None = None
    visual_artifacts: list[Path] = []
    try:
        dataset = generate_wave_dataset(
            samples=config.samples,
            nx=config.nx,
            nt=config.nt,
            c=config.c,
            length=config.length,
            dt=config.dt,
            seed=config.seed,
        )
        save_wave_dataset(paths.dataset, dataset)

        train_config = TrainConfig(
            data=paths.dataset,
            output=paths.checkpoint,
            epochs=config.epochs,
            batch_size=config.batch_size,
            lr=config.lr,
            width=config.width,
            modes=config.modes,
            layers=config.layers,
            val_fraction=config.val_fraction,
            seed=config.seed,
            device=config.device,
            history_output=paths.loss_history,
        )
        checkpoint = train_model(train_config)
        metrics = evaluate_model(
            data=paths.dataset,
            checkpoint_path=paths.checkpoint,
            output=paths.metrics,
            device=config.device,
            batch_size=config.batch_size,
            split=config.eval_split,
        )
        visual_artifacts = create_prediction_visuals(
            data=paths.dataset,
            checkpoint_path=paths.checkpoint,
            sample_index=config.sample_index,
            output_dir=paths.plots_dir,
            device=config.device,
        )
        summary = build_run_summary(
            config=config,
            paths=paths,
            created_at=created_at,
            status="completed",
            checkpoint=checkpoint,
            metrics=metrics,
            visual_artifacts=visual_artifacts,
        )
    except Exception as exc:
        summary = build_run_summary(
            config=config,
            paths=paths,
            created_at=created_at,
            status="failed",
            checkpoint=checkpoint,
            metrics=metrics,
            visual_artifacts=visual_artifacts,
            error=repr(exc),
        )
        write_json(paths.summary, summary)
        update_runs_index(config.index_path, build_index_record(summary))
        raise

    write_json(paths.summary, summary)
    update_runs_index(config.index_path, build_index_record(summary))
    print(f"run: {paths.run_id}")
    print(f"summary: {paths.summary}")
    print(f"runs index: {config.index_path}")
    return summary


def _first_existing_animation(animation_dir: Path, sample_prefix: str) -> Path | None:
    for suffix in ("mp4", "gif"):
        path = animation_dir / f"{sample_prefix}_rollout.{suffix}"
        if path.exists():
            return path
    return None


def _jsonable(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, list | tuple):
        return [_jsonable(item) for item in value]
    if hasattr(value, "item"):
        return value.item()
    return value
