"""Visualization helpers for 1D wave predictions."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")

import matplotlib.animation as animation
import matplotlib.pyplot as plt
import numpy as np
import torch

from neural_operator_wave.dataset1d import Wave1DDataset, load_wave_npz
from neural_operator_wave.training1d import (
    denormalize_prediction,
    load_trained_fno,
    select_device,
)


def predict_sample(
    *,
    data: str | Path,
    checkpoint_path: str | Path,
    sample_index: int,
    device: str = "auto",
) -> dict[str, Any]:
    """Load a sample and model prediction as NumPy arrays."""
    selected = select_device(device)
    print(f"selected device: {selected}")
    try:
        return _predict_sample_on_device(data, checkpoint_path, sample_index, selected)
    except RuntimeError as exc:
        if selected.type != "cuda" or device == "cuda":
            raise
        print(f"CUDA visualization inference failed, falling back to CPU: {exc}")
        return _predict_sample_on_device(
            data, checkpoint_path, sample_index, torch.device("cpu")
        )


def _predict_sample_on_device(
    data: str | Path,
    checkpoint_path: str | Path,
    sample_index: int,
    device: torch.device,
) -> dict[str, Any]:
    dataset = Wave1DDataset(data)
    if not 0 <= sample_index < len(dataset):
        raise IndexError(f"sample_index must be in [0, {len(dataset) - 1}]")
    model, checkpoint = load_trained_fno(checkpoint_path, device)
    sample = dataset[sample_index]
    with torch.no_grad():
        prediction_tensor = denormalize_prediction(
            model(sample["x"].unsqueeze(0).to(device)), checkpoint
        )
        prediction = prediction_tensor.squeeze(0).cpu().numpy()
    target_array = sample["y"].numpy()
    prediction_spatial_std = float(np.std(prediction, axis=1).mean())
    target_spatial_std = float(np.std(target_array, axis=1).mean())
    spatial_std_ratio = prediction_spatial_std / max(target_spatial_std, 1e-12)
    if spatial_std_ratio < 0.1:
        print(
            "warning: prediction has very low spatial variation compared with the target; "
            "this animation may look like a flat line moving in time"
        )
    raw = load_wave_npz(data)
    return {
        "x": np.asarray(raw["x"], dtype=np.float32),
        "t": np.asarray(raw["t"], dtype=np.float32),
        "target": target_array,
        "prediction": prediction,
        "history": checkpoint.get("history", {}),
        "device": str(device),
        "prediction_mean_spatial_std": prediction_spatial_std,
        "target_mean_spatial_std": target_spatial_std,
        "prediction_to_target_spatial_std_ratio": spatial_std_ratio,
    }


def _save_heatmap(
    values: np.ndarray, x: np.ndarray, t: np.ndarray, path: Path, title: str
) -> None:
    fig, ax = plt.subplots(figsize=(8, 4.5))
    image = ax.imshow(
        values,
        aspect="auto",
        origin="lower",
        extent=[float(x[0]), float(x[-1]), float(t[0]), float(t[-1])],
        cmap="viridis",
    )
    ax.set_xlabel("x")
    ax.set_ylabel("t")
    ax.set_title(title)
    fig.colorbar(image, ax=ax, label="u")
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def plot_wave_heatmaps(
    result: dict[str, Any], output_dir: str | Path, *, sample_index: int
) -> list[Path]:
    """Write true, predicted, and absolute-error heatmaps."""
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    x = result["x"]
    t = result["t"]
    target = result["target"]
    prediction = result["prediction"]
    prefix = f"sample_{sample_index:03d}"
    paths = [
        output / f"{prefix}_true.png",
        output / f"{prefix}_prediction.png",
        output / f"{prefix}_absolute_error.png",
    ]
    _save_heatmap(target, x, t, paths[0], "True trajectory")
    _save_heatmap(prediction, x, t, paths[1], "Predicted trajectory")
    _save_heatmap(np.abs(prediction - target), x, t, paths[2], "Absolute error")
    return paths


def plot_error_vs_time(
    result: dict[str, Any], output_dir: str | Path, *, sample_index: int
) -> Path:
    """Write a mean-absolute-error-over-time plot."""
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    error = np.mean(np.abs(result["prediction"] - result["target"]), axis=1)
    path = output / f"sample_{sample_index:03d}_error_vs_time.png"
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.plot(result["t"], error)
    ax.set_xlabel("t")
    ax.set_ylabel("mean absolute error")
    ax.set_title("Prediction error vs time")
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)
    return path


def animate_wave_rollout(
    result: dict[str, Any], output_dir: str | Path, *, sample_index: int
) -> Path | None:
    """Write an animation if an available Matplotlib writer is present."""
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    x = result["x"]
    t = result["t"]
    target = result["target"]
    prediction = result["prediction"]
    ymin = float(min(target.min(), prediction.min()))
    ymax = float(max(target.max(), prediction.max()))
    pad = 0.1 * max(1e-6, ymax - ymin)

    fig, ax = plt.subplots(figsize=(7, 4))
    (true_line,) = ax.plot(x, target[0], label="true")
    (pred_line,) = ax.plot(x, prediction[0], label="predicted")
    ax.set_ylim(ymin - pad, ymax + pad)
    ax.set_xlabel("x")
    ax.set_ylabel("u")
    ax.legend()
    title = ax.set_title("t = 0.000")

    def update(frame: int) -> tuple[Any, ...]:
        true_line.set_ydata(target[frame])
        pred_line.set_ydata(prediction[frame])
        title.set_text(f"t = {t[frame]:.3f}")
        return true_line, pred_line, title

    anim = animation.FuncAnimation(fig, update, frames=len(t), interval=60, blit=False)
    if animation.writers.is_available("ffmpeg"):
        path = output / f"sample_{sample_index:03d}_rollout.mp4"
        anim.save(path, writer="ffmpeg", dpi=120)
    elif animation.writers.is_available("pillow"):
        path = output / f"sample_{sample_index:03d}_rollout.gif"
        anim.save(path, writer="pillow", dpi=100)
    else:
        plt.close(fig)
        return None
    plt.close(fig)
    return path


def create_prediction_visuals(
    *,
    data: str | Path,
    checkpoint_path: str | Path,
    sample_index: int,
    output_dir: str | Path,
    device: str = "auto",
) -> list[Path]:
    """Run inference and create all available visual artifacts."""
    result = predict_sample(
        data=data,
        checkpoint_path=checkpoint_path,
        sample_index=sample_index,
        device=device,
    )
    paths = plot_wave_heatmaps(result, output_dir, sample_index=sample_index)
    paths.append(plot_error_vs_time(result, output_dir, sample_index=sample_index))
    animation_dir = Path(output_dir).parent / "animations"
    animation_path = animate_wave_rollout(
        result, animation_dir, sample_index=sample_index
    )
    if animation_path is not None:
        paths.append(animation_path)
    for path in paths:
        print(f"artifact: {path}")
    return paths
