"""Finite-difference solver for the fixed-end 1D wave equation."""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray


FloatArray = NDArray[np.float32]


def stable_dt(nx: int, c: float = 1.0, length: float = 1.0, cfl: float = 0.5) -> float:
    """Return a stable explicit-solver time step for a uniform grid."""
    if nx < 3:
        raise ValueError("nx must be at least 3")
    if c <= 0:
        raise ValueError("c must be positive")
    if length <= 0:
        raise ValueError("length must be positive")
    if not 0 < cfl <= 1:
        raise ValueError("cfl must satisfy 0 < cfl <= 1")
    dx = length / (nx - 1)
    return cfl * dx / c


def solve_wave_1d(
    u0: NDArray[np.floating],
    v0: NDArray[np.floating],
    *,
    c: float = 1.0,
    length: float = 1.0,
    dt: float | None = None,
    nt: int = 80,
    cfl: float = 0.5,
) -> tuple[FloatArray, FloatArray, FloatArray]:
    """Solve ``u_tt = c^2 u_xx`` with fixed zero displacement at both ends."""
    u0_arr = np.asarray(u0, dtype=np.float32).copy()
    v0_arr = np.asarray(v0, dtype=np.float32).copy()
    if u0_arr.ndim != 1 or v0_arr.ndim != 1:
        raise ValueError("u0 and v0 must be one-dimensional")
    if u0_arr.shape != v0_arr.shape:
        raise ValueError("u0 and v0 must have the same shape")
    if nt < 2:
        raise ValueError("nt must be at least 2")
    if c <= 0:
        raise ValueError("c must be positive")
    if length <= 0:
        raise ValueError("length must be positive")

    nx = u0_arr.shape[0]
    if nx < 3:
        raise ValueError("u0 and v0 must contain at least 3 grid points")

    dx = length / (nx - 1)
    step = stable_dt(nx, c=c, length=length, cfl=cfl) if dt is None else float(dt)
    if step <= 0:
        raise ValueError("dt must be positive")
    courant = c * step / dx
    if courant > 1.0 + 1e-7:
        raise ValueError(f"unstable Courant number {courant:.3f}; require <= 1")

    x = np.linspace(0.0, length, nx, dtype=np.float32)
    t = np.arange(nt, dtype=np.float32) * np.float32(step)
    trajectory = np.zeros((nt, nx), dtype=np.float32)

    u0_arr[[0, -1]] = 0.0
    v0_arr[[0, -1]] = 0.0
    trajectory[0] = u0_arr

    r2 = np.float32(courant * courant)
    lap0 = u0_arr[2:] - 2.0 * u0_arr[1:-1] + u0_arr[:-2]
    trajectory[1, 1:-1] = u0_arr[1:-1] + step * v0_arr[1:-1] + 0.5 * r2 * lap0

    for n in range(1, nt - 1):
        lap = trajectory[n, 2:] - 2.0 * trajectory[n, 1:-1] + trajectory[n, :-2]
        trajectory[n + 1, 1:-1] = (
            2.0 * trajectory[n, 1:-1] - trajectory[n - 1, 1:-1] + r2 * lap
        )

    trajectory[:, 0] = 0.0
    trajectory[:, -1] = 0.0
    return x, t, trajectory
