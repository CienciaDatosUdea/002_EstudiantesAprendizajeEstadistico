"""Dataset generation and PyTorch loading for 1D wave trajectories."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
from numpy.typing import NDArray
import torch
from torch.utils.data import Dataset

from neural_operator_wave.initial_conditions import sample_initial_condition
from neural_operator_wave.wave1d import solve_wave_1d, stable_dt


def generate_wave_dataset(
    *,
    samples: int,
    nx: int,
    nt: int,
    c: float = 1.0,
    length: float = 1.0,
    dt: float | None = None,
    seed: int = 0,
) -> dict[str, Any]:
    """Generate a collection of finite-difference 1D wave trajectories."""
    if samples <= 0:
        raise ValueError("samples must be positive")
    rng = np.random.default_rng(seed)
    x = np.linspace(0.0, length, nx, dtype=np.float32)
    step = stable_dt(nx, c=c, length=length, cfl=0.5) if dt is None else float(dt)

    u0 = np.zeros((samples, nx), dtype=np.float32)
    v0 = np.zeros((samples, nx), dtype=np.float32)
    trajectory = np.zeros((samples, nt, nx), dtype=np.float32)
    t: NDArray[np.float32] | None = None

    for i in range(samples):
        sample_u0, sample_v0 = sample_initial_condition(x, rng, length=length)
        solve_x, solve_t, sample_trajectory = solve_wave_1d(
            sample_u0,
            sample_v0,
            c=c,
            length=length,
            dt=step,
            nt=nt,
        )
        x = solve_x
        t = solve_t
        u0[i] = sample_u0
        v0[i] = sample_v0
        trajectory[i] = sample_trajectory

    if t is None:
        raise RuntimeError("dataset generation produced no samples")
    dx = length / (nx - 1)
    return {
        "u0": u0,
        "v0": v0,
        "trajectory": trajectory,
        "x": x.astype(np.float32),
        "t": t.astype(np.float32),
        "c": np.float32(c),
        "length": np.float32(length),
        "dt": np.float32(step),
        "dx": np.float32(dx),
        "nx": np.int32(nx),
        "nt": np.int32(nt),
        "samples": np.int32(samples),
        "seed": np.int32(seed),
        "boundary_condition": "fixed_dirichlet",
    }


def save_wave_dataset(path: str | Path, dataset: dict[str, Any]) -> Path:
    """Write a generated dataset as a compressed ``.npz`` file."""
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(output, **dataset)
    return output


def load_wave_npz(path: str | Path) -> dict[str, Any]:
    """Load a wave dataset into regular NumPy arrays and Python scalars."""
    with np.load(path, allow_pickle=False) as data:
        loaded: dict[str, Any] = {key: data[key] for key in data.files}
    for key in ("c", "length", "dt", "dx"):
        if key in loaded:
            loaded[key] = float(np.asarray(loaded[key]))
    for key in ("nx", "nt", "samples", "seed"):
        if key in loaded:
            loaded[key] = int(np.asarray(loaded[key]))
    if "boundary_condition" in loaded:
        loaded["boundary_condition"] = str(np.asarray(loaded["boundary_condition"]))
    return loaded


class Wave1DDataset(Dataset[dict[str, torch.Tensor]]):
    """NeuralOp-native dataset emitting ``{"x": ..., "y": ...}`` samples.

    ``x`` has shape ``(channels, nx)`` and ``y`` has shape ``(nt, nx)``.
    PyTorch's default collation turns those into ``(batch, channels, nx)`` and
    ``(batch, nt, nx)``, matching ``neuralop.models.FNO`` directly.
    """

    def __init__(
        self,
        path: str | Path,
        *,
        target_mean: float = 0.0,
        target_std: float = 1.0,
    ) -> None:
        self.path = Path(path)
        data = load_wave_npz(self.path)
        self.u0 = np.asarray(data["u0"], dtype=np.float32)
        self.v0 = np.asarray(data["v0"], dtype=np.float32)
        self.trajectory = np.asarray(data["trajectory"], dtype=np.float32)
        self.x = np.asarray(data["x"], dtype=np.float32)
        self.target_mean = float(target_mean)
        self.target_std = max(float(target_std), 1e-6)
        if self.u0.shape != self.v0.shape:
            raise ValueError("u0 and v0 shapes differ")
        if (
            self.trajectory.shape[0] != self.u0.shape[0]
            or self.trajectory.shape[2] != self.u0.shape[1]
        ):
            raise ValueError("trajectory shape is inconsistent with u0/v0")

    @property
    def input_channels(self) -> int:
        return 3

    @property
    def nt(self) -> int:
        return int(self.trajectory.shape[1])

    @property
    def nx(self) -> int:
        return int(self.u0.shape[1])

    def __len__(self) -> int:
        return int(self.u0.shape[0])

    def __getitem__(self, index: int) -> dict[str, torch.Tensor]:
        inputs = np.stack([self.u0[index], self.v0[index], self.x], axis=0).astype(
            np.float32
        )
        target = (self.trajectory[index] - self.target_mean) / self.target_std
        return {
            "x": torch.from_numpy(inputs),
            "y": torch.from_numpy(target.astype(np.float32)),
        }
