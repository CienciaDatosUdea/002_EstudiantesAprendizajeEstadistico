"""Evaluation metrics for trained 1D wave models."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch.utils.data import DataLoader, Subset

from neural_operator_wave.dataset1d import Wave1DDataset
from neural_operator_wave.training1d import (
    denormalize_prediction,
    deterministic_split,
    load_trained_fno,
    select_device,
)


def _metrics(prediction: torch.Tensor, target: torch.Tensor) -> dict[str, Any]:
    diff = prediction - target
    mse = torch.mean(diff**2)
    mae = torch.mean(torch.abs(diff))
    rel_l2 = torch.linalg.vector_norm(diff) / torch.clamp(
        torch.linalg.vector_norm(target), min=1e-12
    )
    error_by_time = torch.mean(torch.abs(diff), dim=(0, 2))
    prediction_spatial_std = torch.std(prediction, dim=2).mean()
    target_spatial_std = torch.std(target, dim=2).mean()
    spatial_std_ratio = prediction_spatial_std / torch.clamp(
        target_spatial_std, min=1e-12
    )
    return {
        "mse": float(mse.cpu()),
        "mae": float(mae.cpu()),
        "relative_l2": float(rel_l2.cpu()),
        "error_by_time": error_by_time.cpu().numpy().astype(float).tolist(),
        "prediction_mean_spatial_std": float(prediction_spatial_std.cpu()),
        "target_mean_spatial_std": float(target_spatial_std.cpu()),
        "prediction_to_target_spatial_std_ratio": float(spatial_std_ratio.cpu()),
        "spatial_collapse_warning": bool(float(spatial_std_ratio.cpu()) < 0.1),
    }


def evaluate_model(
    *,
    data: str | Path,
    checkpoint_path: str | Path,
    output: str | Path,
    device: str = "auto",
    batch_size: int = 32,
    split: str = "val",
) -> dict[str, Any]:
    """Evaluate a checkpoint and write metrics JSON."""
    selected = select_device(device)
    print(f"selected device: {selected}")
    try:
        return _evaluate_on_device(
            data, checkpoint_path, output, selected, batch_size, split
        )
    except RuntimeError as exc:
        if selected.type != "cuda" or device == "cuda":
            raise
        print(f"CUDA evaluation failed, falling back to CPU: {exc}")
        return _evaluate_on_device(
            data, checkpoint_path, output, torch.device("cpu"), batch_size, split
        )


def _evaluate_on_device(
    data: str | Path,
    checkpoint_path: str | Path,
    output: str | Path,
    device: torch.device,
    batch_size: int,
    split: str,
) -> dict[str, Any]:
    dataset = Wave1DDataset(data)
    model, checkpoint = load_trained_fno(checkpoint_path, device)
    indices = evaluation_indices(checkpoint, len(dataset), split)

    loader = DataLoader(Subset(dataset, indices), batch_size=batch_size, shuffle=False)
    predictions: list[torch.Tensor] = []
    targets: list[torch.Tensor] = []
    with torch.no_grad():
        for sample in loader:
            inputs = sample["x"].to(device)
            batch_predictions = denormalize_prediction(model(inputs), checkpoint).cpu()
            predictions.append(batch_predictions)
            targets.append(sample["y"].cpu())
    prediction = torch.cat(predictions, dim=0)
    target = torch.cat(targets, dim=0)
    metrics = _metrics(prediction, target)
    metrics.update(
        {
            "samples_evaluated": len(indices),
            "split": split,
            "device": str(device),
            "data": str(data),
            "checkpoint": str(checkpoint_path),
            "prediction_shape": list(prediction.shape),
            "target_shape": list(target.shape),
            "mean_target_abs": float(np.mean(np.abs(target.numpy()))),
        }
    )
    output_path = Path(output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    print(f"metrics: {output_path}")
    print(
        f"mse={metrics['mse']:.6g} mae={metrics['mae']:.6g} relative_l2={metrics['relative_l2']:.6g}"
    )
    if metrics["spatial_collapse_warning"]:
        print(
            "warning: prediction has very low spatial variation compared with the target; "
            "train longer or use a larger dataset before judging animations"
        )
    return metrics


def evaluation_indices(
    checkpoint: dict[str, Any], dataset_size: int, split: str
) -> list[int]:
    """Return evaluation indices using checkpoint split metadata when available."""
    if split == "val" and "val_indices" in checkpoint:
        return list(checkpoint["val_indices"])
    if split == "train" and "train_indices" in checkpoint:
        return list(checkpoint["train_indices"])
    if split == "all":
        return list(range(dataset_size))

    train_config = checkpoint.get("train_config", {})
    val_fraction = float(train_config.get("val_fraction", 0.2))
    seed = int(train_config.get("seed", 0))
    train_indices, val_indices = deterministic_split(dataset_size, val_fraction, seed)
    if split == "val":
        return val_indices
    if split == "train":
        return train_indices
    raise ValueError("split must be one of: train, val, all")
