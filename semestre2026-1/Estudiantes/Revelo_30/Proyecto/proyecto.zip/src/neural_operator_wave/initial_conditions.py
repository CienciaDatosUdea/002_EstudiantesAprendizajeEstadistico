"""Initial-condition samplers for 1D fixed-end waves."""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray


def _with_fixed_boundaries(values: NDArray[np.floating]) -> NDArray[np.float32]:
    out = np.asarray(values, dtype=np.float32).copy()
    out[[0, -1]] = 0.0
    return out


def random_fourier_modes(
    x: NDArray[np.floating],
    rng: np.random.Generator,
    *,
    modes: int = 5,
    amplitude: float = 1.0,
    spectral_decay: float = 2.0,
    length: float = 1.0,
) -> NDArray[np.float32]:
    """Sample a smooth sine-series profile satisfying fixed-end boundaries."""
    values = np.zeros_like(np.asarray(x, dtype=np.float32))
    for k in range(1, modes + 1):
        coeff = rng.normal(0.0, amplitude / (k**spectral_decay))
        values += coeff * np.sin(k * np.pi * x / length)
    max_abs = float(np.max(np.abs(values)))
    if max_abs > 0:
        values = amplitude * values / max_abs
    return _with_fixed_boundaries(values)


def plucked_string_profile(
    x: NDArray[np.floating],
    *,
    pluck_position: float,
    amplitude: float = 1.0,
    length: float = 1.0,
) -> NDArray[np.float32]:
    """Return a triangular fixed-string displacement profile."""
    if not 0.0 < pluck_position < length:
        raise ValueError("pluck_position must lie strictly inside the string")
    x_arr = np.asarray(x, dtype=np.float32)
    values = np.empty_like(x_arr)
    left = x_arr <= pluck_position
    values[left] = amplitude * x_arr[left] / pluck_position
    values[~left] = amplitude * (length - x_arr[~left]) / (length - pluck_position)
    return _with_fixed_boundaries(values)


def smooth_fixed_end_bump(
    x: NDArray[np.floating],
    *,
    center: float,
    width: float,
    amplitude: float = 1.0,
    length: float = 1.0,
) -> NDArray[np.float32]:
    """Return a localized smooth bump that naturally vanishes at fixed ends."""
    if width <= 0:
        raise ValueError("width must be positive")
    x_arr = np.asarray(x, dtype=np.float32)
    gaussian = np.exp(-0.5 * ((x_arr - center) / width) ** 2)
    envelope = np.sin(np.pi * x_arr / length)
    values = gaussian * envelope
    max_abs = float(np.max(np.abs(values)))
    if max_abs > 0:
        values = amplitude * values / max_abs
    return _with_fixed_boundaries(values)


def sample_initial_condition(
    x: NDArray[np.floating],
    rng: np.random.Generator,
    *,
    length: float = 1.0,
) -> tuple[NDArray[np.float32], NDArray[np.float32]]:
    """Sample a displacement and velocity pair for dataset generation."""
    displacement_family = rng.random()
    if displacement_family < 0.5:
        u0 = random_fourier_modes(
            x,
            rng,
            modes=int(rng.integers(3, 17)),
            amplitude=rng.uniform(0.5, 1.0),
            spectral_decay=rng.uniform(1.25, 2.25),
            length=length,
        )
    elif displacement_family < 0.8:
        pluck_position = rng.uniform(0.15 * length, 0.85 * length)
        amplitude = rng.uniform(0.5, 1.0) * rng.choice([-1.0, 1.0])
        u0 = plucked_string_profile(
            x,
            pluck_position=pluck_position,
            amplitude=amplitude,
            length=length,
        )
    else:
        center = rng.uniform(0.2 * length, 0.8 * length)
        width = rng.uniform(0.04 * length, 0.12 * length)
        amplitude = rng.uniform(0.5, 1.0) * rng.choice([-1.0, 1.0])
        u0 = smooth_fixed_end_bump(
            x, center=center, width=width, amplitude=amplitude, length=length
        )

    if rng.random() < 0.5:
        v0 = np.zeros_like(u0)
    else:
        v0 = 0.5 * random_fourier_modes(
            x,
            rng,
            modes=int(rng.integers(3, 17)),
            amplitude=1.0,
            spectral_decay=rng.uniform(1.25, 2.25),
            length=length,
        )
    return _with_fixed_boundaries(u0), _with_fixed_boundaries(v0)
