"""Tools for 1D wave-equation neural-operator experiments."""

__all__ = ["__version__"]

__version__ = "0.1.0"
