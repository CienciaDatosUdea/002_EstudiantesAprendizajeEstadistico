"""Training utilities for 1D FNO wave prediction."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import json
from pathlib import Path
from typing import Any

from neuralop.losses import LpLoss
from neuralop.models import FNO
from neuralop.training import Trainer
import torch
from torch.utils.data import DataLoader, Subset

from neural_operator_wave.dataset1d import Wave1DDataset, load_wave_npz


@dataclass(frozen=True)
class TrainConfig:
    data: Path
    output: Path
    epochs: int = 5
    batch_size: int = 16
    lr: float = 1e-3
    width: int = 32
    modes: int = 12
    layers: int = 4
    val_fraction: float = 0.2
    seed: int = 0
    device: str = "auto"
    history_output: Path | None = None


def select_device(requested: str = "auto") -> torch.device:
    """Select CUDA first for ``auto`` and otherwise honor an explicit device."""
    if requested == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if requested == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is not available to PyTorch")
    if requested not in {"cuda", "cpu"}:
        raise ValueError("device must be one of: auto, cuda, cpu")
    return torch.device(requested)


def deterministic_split(
    size: int, val_fraction: float, seed: int
) -> tuple[list[int], list[int]]:
    """Return deterministic train/validation indices."""
    if size < 2:
        raise ValueError("dataset must contain at least 2 samples")
    if not 0 < val_fraction < 1:
        raise ValueError("val_fraction must satisfy 0 < val_fraction < 1")
    generator = torch.Generator().manual_seed(seed)
    indices = torch.randperm(size, generator=generator).tolist()
    val_size = max(1, int(round(size * val_fraction)))
    val_size = min(val_size, size - 1)
    return indices[val_size:], indices[:val_size]


def build_model(
    input_channels: int, nt: int, *, width: int, modes: int, layers: int
) -> FNO:
    """Build NeuralOp's native FNO with project CLI parameter names."""
    return FNO(
        n_modes=(modes,),
        in_channels=input_channels,
        out_channels=nt,
        hidden_channels=width,
        n_layers=layers,
        positional_embedding=None,
    )


def _run_training_on_device(
    config: TrainConfig, device: torch.device
) -> dict[str, Any]:
    torch.manual_seed(config.seed)
    base_dataset = Wave1DDataset(config.data)
    train_indices, val_indices = deterministic_split(
        len(base_dataset), config.val_fraction, config.seed
    )
    train_targets = torch.from_numpy(base_dataset.trajectory[train_indices])
    target_mean = float(train_targets.mean())
    target_std = float(train_targets.std().clamp_min(1e-6))
    dataset = Wave1DDataset(config.data, target_mean=target_mean, target_std=target_std)
    train_loader = DataLoader(
        Subset(dataset, train_indices), batch_size=config.batch_size, shuffle=True
    )
    val_loader = DataLoader(
        Subset(dataset, val_indices), batch_size=config.batch_size, shuffle=False
    )

    model = build_model(
        dataset.input_channels,
        dataset.nt,
        width=config.width,
        modes=config.modes,
        layers=config.layers,
    )
    optimizer = torch.optim.AdamW(model.parameters(), lr=config.lr)
    scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda=lambda _: 1.0)
    train_loss = LpLoss(d=1, p=2)
    eval_losses = {"l2": LpLoss(d=1, p=2)}
    trainer = Trainer(
        model=model,
        n_epochs=config.epochs,
        device=str(device),
        verbose=True,
        eval_interval=1,
    )
    final_metrics = trainer.train(
        train_loader=train_loader,
        test_loaders={"val": val_loader},
        optimizer=optimizer,
        scheduler=scheduler,
        regularizer=False,
        training_loss=train_loss,
        eval_losses=eval_losses,
    )
    trainer_metrics = {
        key: _metric_to_jsonable(value) for key, value in final_metrics.items()
    }
    history: dict[str, Any] = {"final_trainer_metrics": trainer_metrics}

    metadata = load_wave_npz(config.data)
    checkpoint = {
        "model_state_dict": _clean_state_dict(trainer.model.cpu().state_dict()),
        "model_name": "FNO",
        "model_library": "neuralop",
        "model_impl": "neuralop.models.FNO",
        "trainer_library": "neuralop",
        "trainer_impl": "neuralop.training.Trainer",
        "loss_impl": "neuralop.losses.LpLoss",
        "model_config": {
            "n_modes": (config.modes,),
            "in_channels": dataset.input_channels,
            "out_channels": dataset.nt,
            "hidden_channels": config.width,
            "n_layers": config.layers,
            "positional_embedding": None,
        },
        "train_config": {
            key: str(value) if isinstance(value, Path) else value
            for key, value in asdict(config).items()
        },
        "history": history,
        "target_normalization": {"mean": target_mean, "std": target_std},
        "dataset_metadata": {
            key: value
            for key, value in metadata.items()
            if key not in {"u0", "v0", "trajectory", "x", "t"}
        },
        "train_indices": train_indices,
        "val_indices": val_indices,
        "selected_device": str(device),
    }
    config.output.parent.mkdir(parents=True, exist_ok=True)
    torch.save(checkpoint, config.output)

    if config.history_output is None:
        log_dir = Path("artifacts/1d/logs")
        log_dir.mkdir(parents=True, exist_ok=True)
        history_path = log_dir / f"{config.output.stem}_loss_history.json"
    else:
        history_path = config.history_output
        history_path.parent.mkdir(parents=True, exist_ok=True)
    history_path.write_text(json.dumps(history, indent=2), encoding="utf-8")
    print(f"checkpoint: {config.output}")
    print(f"loss history: {history_path}")
    return checkpoint


def train_model(config: TrainConfig) -> dict[str, Any]:
    """Train with CUDA-first selection and CPU fallback for recoverable CUDA errors."""
    device = select_device(config.device)
    print(f"selected device: {device}")
    try:
        return _run_training_on_device(config, device)
    except RuntimeError as exc:
        if device.type != "cuda" or config.device == "cuda":
            raise
        print(f"CUDA training failed, falling back to CPU: {exc}")
        cpu_config = TrainConfig(**{**asdict(config), "device": "cpu"})
        return _run_training_on_device(cpu_config, torch.device("cpu"))


def _clean_state_dict(state_dict: dict[str, Any]) -> dict[str, Any]:
    """Remove NeuralOp bookkeeping keys that are not model parameters."""
    return {key: value for key, value in state_dict.items() if key != "_metadata"}


def _metric_to_jsonable(value: Any) -> float | None:
    if value is None:
        return None
    if torch.is_tensor(value):
        return float(value.detach().cpu())
    return float(value)


def load_trained_fno(
    checkpoint_path: str | Path, device: torch.device
) -> tuple[FNO, dict[str, Any]]:
    """Load a trained FNO checkpoint for evaluation or visualization."""
    checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=False)
    model = FNO(**checkpoint["model_config"]).to(device)
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()
    return model, checkpoint


def denormalize_prediction(
    prediction: torch.Tensor, checkpoint: dict[str, Any]
) -> torch.Tensor:
    """Convert normalized model output back to physical displacement units."""
    normalization = checkpoint.get("target_normalization")
    if not normalization:
        return prediction
    mean = float(normalization["mean"])
    std = float(normalization["std"])
    return prediction * std + mean
