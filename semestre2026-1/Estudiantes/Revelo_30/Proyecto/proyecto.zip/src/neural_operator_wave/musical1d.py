"""Modal and plucked-string utilities for the 1D wave equation."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np
from numpy.typing import NDArray


FloatArray = NDArray[np.float32]


@dataclass(frozen=True)
class MusicalCase:
    """A physically interpretable vibrating-string initial condition."""

    name: str
    case_type: str
    description: str
    u0: FloatArray
    v0: FloatArray
    metadata: dict[str, Any]


def pure_mode_initial_condition(
    x: NDArray[np.floating],
    *,
    mode: int,
    amplitude: float = 1.0,
    length: float = 1.0,
) -> tuple[FloatArray, FloatArray]:
    """Return a single fixed-string sine mode and zero initial velocity."""
    if mode < 1:
        raise ValueError("mode must be at least 1")
    x_arr = np.asarray(x, dtype=np.float32)
    u0 = amplitude * np.sin(mode * np.pi * x_arr / length)
    u0[[0, -1]] = 0.0
    v0 = np.zeros_like(u0)
    return u0.astype(np.float32), v0.astype(np.float32)


def harmonic_mixture_initial_condition(
    x: NDArray[np.floating],
    amplitudes: dict[int, float],
    *,
    peak_amplitude: float = 1.0,
    length: float = 1.0,
) -> tuple[FloatArray, FloatArray]:
    """Return a normalized sum of fixed-string sine modes."""
    if not amplitudes:
        raise ValueError("amplitudes must not be empty")
    x_arr = np.asarray(x, dtype=np.float32)
    u0 = np.zeros_like(x_arr)
    for mode, amplitude in amplitudes.items():
        if mode < 1:
            raise ValueError("all modes must be at least 1")
        u0 += float(amplitude) * np.sin(mode * np.pi * x_arr / length)
    u0 = normalize_peak(u0, peak_amplitude=peak_amplitude)
    u0[[0, -1]] = 0.0
    v0 = np.zeros_like(u0)
    return u0.astype(np.float32), v0.astype(np.float32)


def plucked_string_initial_condition(
    x: NDArray[np.floating],
    *,
    pluck_position: float,
    amplitude: float = 1.0,
    length: float = 1.0,
) -> tuple[FloatArray, FloatArray]:
    """Return a triangular plucked-string displacement and zero velocity."""
    if not 0.0 < pluck_position < length:
        raise ValueError("pluck_position must lie inside the string")
    x_arr = np.asarray(x, dtype=np.float32)
    left = x_arr / pluck_position
    right = (length - x_arr) / (length - pluck_position)
    u0 = amplitude * np.minimum(left, right)
    u0 = np.maximum(u0, 0.0)
    u0[[0, -1]] = 0.0
    v0 = np.zeros_like(u0)
    return u0.astype(np.float32), v0.astype(np.float32)


def default_musical_cases(
    x: NDArray[np.floating], *, length: float = 1.0, amplitude: float = 1.0
) -> list[MusicalCase]:
    """Build the focused pure-mode, harmonic-mixture, and plucked-string cases."""
    cases: list[MusicalCase] = []
    for mode in (1, 2, 3, 5, 8):
        u0, v0 = pure_mode_initial_condition(
            x, mode=mode, amplitude=amplitude, length=length
        )
        cases.append(
            MusicalCase(
                name=f"pure_mode_{mode:02d}",
                case_type="pure_mode",
                description=f"Pure standing-wave mode {mode}",
                u0=u0,
                v0=v0,
                metadata={"mode": mode, "amplitude": amplitude},
            )
        )

    mixtures = {
        "harmonic_mellow": {1: 1.0, 2: 0.25, 3: 0.10, 4: 0.05},
        "harmonic_bright": {1: 1.0, 2: 0.60, 3: 0.40, 4: 0.25, 5: 0.15},
        "harmonic_odd_modes": {1: 1.0, 3: 0.35, 5: 0.20, 7: 0.10},
    }
    for name, amplitudes in mixtures.items():
        u0, v0 = harmonic_mixture_initial_condition(
            x, amplitudes, peak_amplitude=amplitude, length=length
        )
        cases.append(
            MusicalCase(
                name=name,
                case_type="harmonic_mixture",
                description=f"Harmonic mixture with amplitudes {amplitudes}",
                u0=u0,
                v0=v0,
                metadata={"amplitudes": amplitudes, "peak_amplitude": amplitude},
            )
        )

    plucks = {
        "pluck_center": 0.50 * length,
        "pluck_one_third": length / 3.0,
        "pluck_near_bridge": 0.15 * length,
    }
    for name, position in plucks.items():
        u0, v0 = plucked_string_initial_condition(
            x, pluck_position=position, amplitude=amplitude, length=length
        )
        cases.append(
            MusicalCase(
                name=name,
                case_type="plucked_string",
                description=f"Triangular pluck at x={position:.3g}",
                u0=u0,
                v0=v0,
                metadata={"pluck_position": position, "amplitude": amplitude},
            )
        )
    return cases


def normalize_peak(
    values: NDArray[np.floating], *, peak_amplitude: float = 1.0
) -> FloatArray:
    """Scale values so their maximum absolute value equals ``peak_amplitude``."""
    arr = np.asarray(values, dtype=np.float32)
    peak = float(np.max(np.abs(arr)))
    if peak <= 1e-12:
        return arr.astype(np.float32)
    return (arr * (peak_amplitude / peak)).astype(np.float32)


def modal_coefficients(
    values: NDArray[np.floating],
    x: NDArray[np.floating],
    *,
    max_mode: int,
    length: float = 1.0,
) -> FloatArray:
    """Project a shape or trajectory onto fixed-string sine modes."""
    if max_mode < 1:
        raise ValueError("max_mode must be at least 1")
    values_arr = np.asarray(values, dtype=np.float32)
    x_arr = np.asarray(x, dtype=np.float32)
    if values_arr.shape[-1] != x_arr.shape[0]:
        raise ValueError("last values dimension must match x")

    modes = np.arange(1, max_mode + 1, dtype=np.float32)
    basis = np.sin(np.pi * modes[:, None] * x_arr[None, :] / length).astype(np.float32)
    integrand = values_arr[..., None, :] * basis
    coefficients = (2.0 / length) * np.trapezoid(integrand, x_arr, axis=-1)
    return coefficients.astype(np.float32)


def modal_rms_spectrum(
    trajectory: NDArray[np.floating],
    x: NDArray[np.floating],
    *,
    max_mode: int,
    length: float = 1.0,
) -> FloatArray:
    """Return RMS modal amplitudes over time for a trajectory."""
    coefficients = modal_coefficients(
        trajectory, x, max_mode=max_mode, length=length
    )
    if coefficients.ndim == 1:
        return np.abs(coefficients).astype(np.float32)
    return np.sqrt(np.mean(coefficients**2, axis=0)).astype(np.float32)


def modal_metrics(
    target: NDArray[np.floating],
    prediction: NDArray[np.floating],
    x: NDArray[np.floating],
    *,
    max_mode: int = 16,
    low_mode_cutoff: int = 4,
    length: float = 1.0,
) -> dict[str, Any]:
    """Compare target and predicted trajectories in modal space."""
    target_spectrum = modal_rms_spectrum(
        target, x, max_mode=max_mode, length=length
    )
    prediction_spectrum = modal_rms_spectrum(
        prediction, x, max_mode=max_mode, length=length
    )
    diff = prediction_spectrum - target_spectrum
    denominator = max(float(np.linalg.norm(target_spectrum)), 1e-12)
    dominant_true = int(np.argmax(target_spectrum) + 1)
    dominant_pred = int(np.argmax(prediction_spectrum) + 1)

    low_slice = slice(0, min(low_mode_cutoff, max_mode))
    high_slice = slice(min(low_mode_cutoff, max_mode), max_mode)
    target_energy = target_spectrum**2
    prediction_energy = prediction_spectrum**2
    target_total = float(np.sum(target_energy))
    pred_total = float(np.sum(prediction_energy))
    target_low = float(np.sum(target_spectrum[low_slice] ** 2))
    pred_low = float(np.sum(prediction_spectrum[low_slice] ** 2))
    target_high = float(np.sum(target_spectrum[high_slice] ** 2))
    pred_high = float(np.sum(prediction_spectrum[high_slice] ** 2))
    target_energy_fraction = normalize_energy_fraction(target_energy)
    prediction_energy_fraction = normalize_energy_fraction(prediction_energy)

    return {
        "dominant_mode_true": dominant_true,
        "dominant_mode_pred": dominant_pred,
        "dominant_mode_match": dominant_true == dominant_pred,
        "modal_spectrum_relative_l2": float(np.linalg.norm(diff) / denominator),
        "modal_energy_fraction_l1": float(
            np.sum(np.abs(prediction_energy_fraction - target_energy_fraction))
        ),
        "total_modal_energy_true": target_total,
        "total_modal_energy_pred": pred_total,
        "low_mode_energy_true": target_low,
        "low_mode_energy_pred": pred_low,
        "low_mode_energy_fraction_true": energy_fraction(target_low, target_total),
        "low_mode_energy_fraction_pred": energy_fraction(pred_low, pred_total),
        "low_mode_energy_absolute_error": float(abs(pred_low - target_low)),
        "low_mode_energy_relative_error": relative_error(pred_low, target_low),
        "high_mode_energy_true": target_high,
        "high_mode_energy_pred": pred_high,
        "high_mode_energy_fraction_true": energy_fraction(target_high, target_total),
        "high_mode_energy_fraction_pred": energy_fraction(pred_high, pred_total),
        "high_mode_energy_absolute_error": float(abs(pred_high - target_high)),
        "high_mode_energy_relative_error": relative_error(pred_high, target_high),
        "target_modal_rms": target_spectrum.astype(float).tolist(),
        "prediction_modal_rms": prediction_spectrum.astype(float).tolist(),
    }


def energy_fraction(energy: float, total_energy: float) -> float:
    """Return a bounded energy fraction with stable zero-total handling."""
    if total_energy <= 1e-12:
        return 0.0
    return float(energy / total_energy)


def normalize_energy_fraction(energy: NDArray[np.floating]) -> NDArray[np.float32]:
    """Return a modal energy distribution that is stable for silent signals."""
    total_energy = float(np.sum(energy))
    if total_energy <= 1e-12:
        return np.zeros_like(energy, dtype=np.float32)
    return (energy / total_energy).astype(np.float32)


def relative_error(prediction: float, target: float) -> float:
    """Return scalar relative error with stable zero-target handling."""
    return float(abs(prediction - target) / max(abs(target), 1e-12))


def trajectory_metrics(
    target: NDArray[np.floating], prediction: NDArray[np.floating]
) -> dict[str, float]:
    """Return displacement-space metrics for one trajectory."""
    target_arr = np.asarray(target, dtype=np.float32)
    prediction_arr = np.asarray(prediction, dtype=np.float32)
    diff = prediction_arr - target_arr
    spatial_std_ratio = float(
        np.std(prediction_arr, axis=1).mean() / max(np.std(target_arr, axis=1).mean(), 1e-12)
    )
    return {
        "mse": float(np.mean(diff**2)),
        "mae": float(np.mean(np.abs(diff))),
        "relative_l2": float(
            np.linalg.norm(diff) / max(float(np.linalg.norm(target_arr)), 1e-12)
        ),
        "midpoint_waveform_mse": float(
            np.mean(diff[:, diff.shape[1] // 2] ** 2)
        ),
        "prediction_to_target_spatial_std_ratio": spatial_std_ratio,
        "spatial_collapse_warning": bool(spatial_std_ratio < 0.1),
    }
