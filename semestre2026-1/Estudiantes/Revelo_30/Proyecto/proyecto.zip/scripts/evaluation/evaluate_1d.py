#!/usr/bin/env python
"""Evaluate a trained 1D FNO checkpoint."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))

from neural_operator_wave.evaluation1d import evaluate_model  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument(
        "--output", type=Path, default=Path("artifacts/1d/eval/fno1d_metrics.json")
    )
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--split", choices=("train", "val", "all"), default="val")
    parser.add_argument("--device", choices=("auto", "cuda", "cpu"), default="auto")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    evaluate_model(
        data=args.data,
        checkpoint_path=args.checkpoint,
        output=args.output,
        device=args.device,
        batch_size=args.batch_size,
        split=args.split,
    )


if __name__ == "__main__":
    main()
