#!/usr/bin/env python
"""Generate a finite-difference 1D wave dataset."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))

from neural_operator_wave.dataset1d import (  # noqa: E402
    generate_wave_dataset,
    save_wave_dataset,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--samples", type=int, default=256)
    parser.add_argument("--nx", type=int, default=128)
    parser.add_argument("--nt", type=int, default=80)
    parser.add_argument("--c", type=float, default=1.0)
    parser.add_argument("--length", type=float, default=1.0)
    parser.add_argument("--dt", type=float, default=None)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--output", type=Path, default=Path("data/1d/wave1d_small.npz"))
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    dataset = generate_wave_dataset(
        samples=args.samples,
        nx=args.nx,
        nt=args.nt,
        c=args.c,
        length=args.length,
        dt=args.dt,
        seed=args.seed,
    )
    output = save_wave_dataset(args.output, dataset)
    print(f"saved: {output}")
    for key in ("u0", "v0", "trajectory", "x", "t"):
        print(f"{key}: shape={dataset[key].shape} dtype={dataset[key].dtype}")
    print(f"samples: {dataset['samples']}")
    print(f"x range: [{dataset['x'][0]:.6g}, {dataset['x'][-1]:.6g}]")
    print(f"t range: [{dataset['t'][0]:.6g}, {dataset['t'][-1]:.6g}]")
    print(f"c: {dataset['c']} dx: {dataset['dx']} dt: {dataset['dt']}")
    print(f"boundary_condition: {dataset['boundary_condition']}")


if __name__ == "__main__":
    main()
