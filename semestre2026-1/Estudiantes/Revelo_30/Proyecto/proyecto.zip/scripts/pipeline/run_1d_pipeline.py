#!/usr/bin/env python
"""Run the complete self-contained 1D wave FNO pipeline."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))

from neural_operator_wave.pipeline1d import PipelineConfig, run_pipeline  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--name", dest="run_name", default="run")
    parser.add_argument("--runs-root", type=Path, default=Path("artifacts/1d/runs"))
    parser.add_argument(
        "--index-path", type=Path, default=Path("artifacts/1d/runs_index.json")
    )
    parser.add_argument("--samples", type=int, default=256)
    parser.add_argument("--nx", type=int, default=128)
    parser.add_argument("--nt", type=int, default=80)
    parser.add_argument("--c", type=float, default=1.0)
    parser.add_argument("--length", type=float, default=1.0)
    parser.add_argument("--dt", type=float, default=None)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--epochs", type=int, default=5)
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--width", type=int, default=32)
    parser.add_argument("--modes", type=int, default=12)
    parser.add_argument("--layers", type=int, default=4)
    parser.add_argument("--val-fraction", type=float, default=0.2)
    parser.add_argument("--device", choices=("auto", "cuda", "cpu"), default="auto")
    parser.add_argument("--eval-split", choices=("train", "val", "all"), default="val")
    parser.add_argument("--sample-index", type=int, default=0)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config = PipelineConfig(
        run_name=args.run_name,
        runs_root=args.runs_root,
        index_path=args.index_path,
        samples=args.samples,
        nx=args.nx,
        nt=args.nt,
        c=args.c,
        length=args.length,
        dt=args.dt,
        seed=args.seed,
        epochs=args.epochs,
        batch_size=args.batch_size,
        lr=args.lr,
        width=args.width,
        modes=args.modes,
        layers=args.layers,
        val_fraction=args.val_fraction,
        device=args.device,
        eval_split=args.eval_split,
        sample_index=args.sample_index,
    )
    run_pipeline(config)


if __name__ == "__main__":
    main()
