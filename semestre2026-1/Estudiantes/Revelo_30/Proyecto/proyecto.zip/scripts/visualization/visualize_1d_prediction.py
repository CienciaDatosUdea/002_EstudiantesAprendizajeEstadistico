#!/usr/bin/env python
"""Create 1D wave prediction plots and animation."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))

from neural_operator_wave.visualization1d import create_prediction_visuals  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--sample-index", type=int, default=0)
    parser.add_argument("--output-dir", type=Path, default=Path("artifacts/1d/plots"))
    parser.add_argument("--device", choices=("auto", "cuda", "cpu"), default="auto")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    create_prediction_visuals(
        data=args.data,
        checkpoint_path=args.checkpoint,
        sample_index=args.sample_index,
        output_dir=args.output_dir,
        device=args.device,
    )


if __name__ == "__main__":
    main()
