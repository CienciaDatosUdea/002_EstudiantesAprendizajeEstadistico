"""
ejemplo_uso.py
==============

Ejemplo de uso de la librería `regresion_lineal_gd` sobre los datos
del Laboratorio 4, comparando el resultado contra
`sklearn.linear_model.LinearRegression`.

Ejecutar con:
    python ejemplos/ejemplo_uso.py
"""

import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

from regresion_lineal_gd import ajustar_regresion_lineal, hipotesis


def main():
    # 1. Datos del laboratorio
    np.random.seed(0)
    X = np.linspace(0, 1, 100)
    y = 0.2 + 0.2 * X + 0.02 * np.random.random(100)

    # 2. Ajuste con la librería (gradiente descendente)
    resultado = ajustar_regresion_lineal(X, y, alpha=0.5)
    theta0_gd, theta1_gd = resultado["theta0"], resultado["theta1"]

    print("=== Gradiente descendente (regresion_lineal_gd) ===")
    print(f"theta0 = {theta0_gd:.6f}")
    print(f"theta1 = {theta1_gd:.6f}")
    print(f"Costo final J = {resultado['costo_final']:.8f}")
    print(f"Iteraciones = {resultado['n_iteraciones']}")

    # 3. Ajuste con scikit-learn, para comparar
    modelo_sklearn = LinearRegression().fit(X.reshape(-1, 1), y)
    print("\n=== scikit-learn (LinearRegression) ===")
    print(f"theta0 (intercept_) = {modelo_sklearn.intercept_:.6f}")
    print(f"theta1 (coef_[0])   = {modelo_sklearn.coef_[0]:.6f}")

    print("\n=== Diferencia absoluta ===")
    print(f"|theta0_gd - theta0_sklearn| = {abs(theta0_gd - modelo_sklearn.intercept_):.8f}")
    print(f"|theta1_gd - theta1_sklearn| = {abs(theta1_gd - modelo_sklearn.coef_[0]):.8f}")

    # 4. Grafica comparativa
    plt.figure()
    plt.scatter(X, y, alpha=0.6, label="Datos")
    plt.plot(X, hipotesis(theta0_gd, theta1_gd, X), color="red",
             label="Gradiente descendente")
    plt.plot(X, modelo_sklearn.predict(X.reshape(-1, 1)), color="blue",
             linestyle="--", label="scikit-learn")
    plt.xlabel("X")
    plt.ylabel("y")
    plt.title("regresion_lineal_gd vs scikit-learn")
    plt.legend()
    plt.tight_layout()
    plt.savefig("comparacion_regresion.png", dpi=150)
    plt.show()


if __name__ == "__main__":
    main()
