"""
core.py
=======

Funciones núcleo para ajustar una regresión lineal simple (una variable)
mediante gradiente descendente, minimizando la función de coste de
error cuadrático medio.

Modelo:
    h_theta(x) = theta0 + theta1 * x

Función de coste:
    J(theta0, theta1) = (1 / 2m) * sum_i (h_theta(x_i) - y_i) ** 2
"""

import numpy as np


def hipotesis(theta0, theta1, X):
    """
    Calcula la hipótesis lineal h_theta(x) = theta0 + theta1 * x.

    Parámetros
    ----------
    theta0 : float
        Término independiente (intercepto).
    theta1 : float
        Pendiente.
    X : array_like
        Valores de entrada.

    Retorna
    -------
    numpy.ndarray
        Valores predichos h_theta(x) para cada elemento de X.
    """
    X = np.asarray(X, dtype=float)
    return theta0 + theta1 * X


def funcion_costo(theta0, theta1, X, Y):
    """
    Calcula la función de coste de error cuadrático medio (MSE / 2)
    para el modelo lineal dado un conjunto de datos (X, Y).

    Parámetros
    ----------
    theta0 : float
        Término independiente.
    theta1 : float
        Pendiente.
    X : array_like
        Valores de entrada.
    Y : array_like
        Valores objetivo (reales).

    Retorna
    -------
    float
        Valor de J(theta0, theta1).
    """
    X = np.asarray(X, dtype=float)
    Y = np.asarray(Y, dtype=float)
    m = len(X)
    error = hipotesis(theta0, theta1, X) - Y
    return (1.0 / (2.0 * m)) * np.sum(error ** 2)


def gradiente_descendente(X, Y, alpha=0.5, epsilon=1e-6, max_iter=100000,
                           theta0_inicial=0.0, theta1_inicial=0.0):
    """
    Ejecuta el algoritmo de gradiente descendente para minimizar la
    función de coste de una regresión lineal simple.

    Parámetros
    ----------
    X : array_like
        Valores de entrada.
    Y : array_like
        Valores objetivo (reales).
    alpha : float, opcional
        Tasa de aprendizaje (learning rate). Por defecto 0.5.
    epsilon : float, opcional
        Criterio de convergencia: se detiene cuando el cambio en
        ambos parámetros es menor que epsilon. Por defecto 1e-6.
    max_iter : int, opcional
        Número máximo de iteraciones. Por defecto 100000.
    theta0_inicial, theta1_inicial : float, opcional
        Valores iniciales de los parámetros. Por defecto 0.0.

    Retorna
    -------
    theta0 : float
        Intercepto ajustado.
    theta1 : float
        Pendiente ajustada.
    historial : list of float
        Historial del valor de J en cada iteración (útil para
        graficar la convergencia).
    """
    X = np.asarray(X, dtype=float)
    Y = np.asarray(Y, dtype=float)
    m = len(X)

    theta0, theta1 = theta0_inicial, theta1_inicial
    historial = [funcion_costo(theta0, theta1, X, Y)]

    for _ in range(max_iter):
        pred = hipotesis(theta0, theta1, X)
        error = pred - Y

        grad0 = (1.0 / m) * np.sum(error)
        grad1 = (1.0 / m) * np.sum(error * X)

        theta0_nuevo = theta0 - alpha * grad0
        theta1_nuevo = theta1 - alpha * grad1

        historial.append(funcion_costo(theta0_nuevo, theta1_nuevo, X, Y))

        if abs(theta0_nuevo - theta0) < epsilon and abs(theta1_nuevo - theta1) < epsilon:
            theta0, theta1 = theta0_nuevo, theta1_nuevo
            break

        theta0, theta1 = theta0_nuevo, theta1_nuevo

    return theta0, theta1, historial


def ajustar_regresion_lineal(X, Y, alpha=0.5, epsilon=1e-6, max_iter=100000,
                              theta0_inicial=0.0, theta1_inicial=0.0):
    """
    Función principal de la librería: ajusta un modelo de regresión
    lineal simple a un conjunto de datos (X, Y) mediante gradiente
    descendente y devuelve un resumen del resultado.

    Parámetros
    ----------
    X, Y : array_like
        Datos de entrada y salida.
    alpha, epsilon, max_iter, theta0_inicial, theta1_inicial :
        Ver `gradiente_descendente`.

    Retorna
    -------
    dict
        Diccionario con las claves:
        - "theta0": intercepto ajustado.
        - "theta1": pendiente ajustada.
        - "costo_final": valor de J en el óptimo encontrado.
        - "historial_costo": lista con la evolución de J.
        - "n_iteraciones": número de iteraciones realizadas.
    """
    theta0, theta1, historial = gradiente_descendente(
        X, Y, alpha=alpha, epsilon=epsilon, max_iter=max_iter,
        theta0_inicial=theta0_inicial, theta1_inicial=theta1_inicial,
    )

    return {
        "theta0": theta0,
        "theta1": theta1,
        "costo_final": historial[-1],
        "historial_costo": historial,
        "n_iteraciones": len(historial) - 1,
    }
