"""
regresion_lineal_gd
====================

Librería mínima para ajustar una regresión lineal simple mediante
gradiente descendente.

Uso rápido:

    from regresion_lineal_gd import ajustar_regresion_lineal

    resultado = ajustar_regresion_lineal(X, Y, alpha=0.5)
    print(resultado["theta0"], resultado["theta1"])
"""

from .core import (
    hipotesis,
    funcion_costo,
    gradiente_descendente,
    ajustar_regresion_lineal,
)

__all__ = [
    "hipotesis",
    "funcion_costo",
    "gradiente_descendente",
    "ajustar_regresion_lineal",
]

__version__ = "0.1.0"
