# regresion_lineal_gd

Librería mínima en Python para ajustar una **regresión lineal simple**
(`y = theta0 + theta1 * x`) mediante el algoritmo de **gradiente
descendente**, minimizando la función de coste de error cuadrático medio.

Desarrollada como parte del Laboratorio 4 (Regresión lineal y gradiente
descendente).

## Contenido de la librería

| Función | Descripción |
|---|---|
| `hipotesis(theta0, theta1, X)` | Calcula `h_theta(x) = theta0 + theta1 * x`. |
| `funcion_costo(theta0, theta1, X, Y)` | Calcula `J(theta0, theta1)`, el error cuadrático medio (dividido por 2). |
| `gradiente_descendente(X, Y, alpha, epsilon, max_iter, ...)` | Ejecuta el gradiente descendente y devuelve `theta0`, `theta1` y el historial de costo. |
| `ajustar_regresion_lineal(X, Y, ...)` | Función principal: ajusta el modelo y devuelve un diccionario con el resumen del resultado. |

## Instalación

Clona o descarga esta carpeta y, desde la raíz del proyecto (donde está
`pyproject.toml`), instala la librería en modo editable con `pip`:

```bash
pip install -e .
```

También puede instalarse de forma normal (no editable):

```bash
pip install .
```

Requiere Python 3.8+ y `numpy`.

## Uso básico

```python
import numpy as np
from regresion_lineal_gd import ajustar_regresion_lineal

# Datos de ejemplo
X = np.linspace(0, 1, 100)
y = 0.2 + 0.2 * X + 0.02 * np.random.random(100)

resultado = ajustar_regresion_lineal(X, y, alpha=0.5)

print("theta0:", resultado["theta0"])
print("theta1:", resultado["theta1"])
print("Costo final:", resultado["costo_final"])
print("Iteraciones:", resultado["n_iteraciones"])
```

También se puede acceder a las funciones individuales:

```python
from regresion_lineal_gd import hipotesis, funcion_costo, gradiente_descendente

theta0, theta1, historial = gradiente_descendente(X, y, alpha=0.5)
prediccion = hipotesis(theta0, theta1, X)
costo = funcion_costo(theta0, theta1, X, y)
```

## Ejemplo completo

En la carpeta `ejemplos/ejemplo_uso.py` se incluye un script que:

1. Genera los datos del laboratorio (`X = np.linspace(0, 1, 100)`,
   `y = 0.2 + 0.2*X + 0.02*np.random.random(100)`).
2. Ajusta el modelo con `ajustar_regresion_lineal`.
3. Compara el resultado contra `sklearn.linear_model.LinearRegression`.
4. Grafica los datos junto con ambas rectas ajustadas.

Para ejecutarlo:

```bash
pip install -e .
pip install scikit-learn matplotlib
python ejemplos/ejemplo_uso.py
```

## Estructura del proyecto

```
regresion_lineal_gd/
├── pyproject.toml
├── README.md
├── regresion_lineal_gd/
│   ├── __init__.py
│   └── core.py
└── ejemplos/
    └── ejemplo_uso.py
```
