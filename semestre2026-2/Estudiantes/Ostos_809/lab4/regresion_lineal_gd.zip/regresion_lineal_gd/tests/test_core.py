import numpy as np
import pytest

from regresion_lineal_gd import cost_function, fit, gradient_descent, hypothesis


def test_hypothesis():
    assert np.allclose(hypothesis([0, 1, 2], (1, 2)), [1, 3, 5])


def test_cost_zero_on_perfect_fit():
    X = np.linspace(0, 1, 10)
    assert cost_function(X, 1 + 2 * X, (1, 2)) == pytest.approx(0.0)


def test_fit_recovers_parameters():
    X = np.linspace(0, 1, 100)
    y = 0.2 + 0.2 * X
    res = fit(X, y, alpha=0.5, n_iter=50_000)
    assert res.theta0 == pytest.approx(0.2, abs=1e-3)
    assert res.theta1 == pytest.approx(0.2, abs=1e-3)


def test_cost_decreases():
    X = np.linspace(0, 1, 50)
    _, hist, _ = gradient_descent(X, 3 * X + 1, alpha=0.1, n_iter=200)
    assert np.all(np.diff(hist) <= 1e-12)


def test_invalid_inputs():
    with pytest.raises(ValueError):
        cost_function([1, 2, 3], [1, 2], (0, 0))
    with pytest.raises(ValueError):
        gradient_descent([1, 2], [1, 2], alpha=-1)
