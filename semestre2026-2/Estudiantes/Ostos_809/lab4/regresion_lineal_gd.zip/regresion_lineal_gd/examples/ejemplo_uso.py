"""Ejemplo de uso de regresion_lineal_gd con los datos del laboratorio.

Instalación (desde la carpeta que contiene pyproject.toml):

    pip install -e .
    pip install matplotlib scikit-learn    # solo para este ejemplo

Ejecución:

    python examples/ejemplo_uso.py
"""

import matplotlib.pyplot as plt
import numpy as np
from sklearn.linear_model import LinearRegression

from regresion_lineal_gd import fit

# Datos del laboratorio
np.random.seed(0)
X = np.linspace(0, 1, 100)
y = 0.2 + 0.2 * X + 0.02 * np.random.random(100)

# Ajuste con gradiente descendente
res = fit(X, y, alpha=0.5, n_iter=50_000, tol=1e-12)
print("Gradiente descendente:", res)

# Comparación con scikit-learn
sk = LinearRegression().fit(X.reshape(-1, 1), y)
print(f"scikit-learn: theta0={sk.intercept_:.6f}, theta1={sk.coef_[0]:.6f}")

# Gráficas
fig, ax = plt.subplots(1, 2, figsize=(11, 4))
ax[0].scatter(X, y, s=10, label="datos")
ax[0].plot(X, res.predict(X), "r", label="GD")
ax[0].set_xlabel("X"); ax[0].set_ylabel("y"); ax[0].legend()
ax[1].plot(res.cost_history)
ax[1].set_xscale("log"); ax[1].set_yscale("log")
ax[1].set_xlabel("iteración"); ax[1].set_ylabel("J")
plt.tight_layout()
plt.savefig("ejemplo_resultado.png", dpi=120)
print("Figura guardada en ejemplo_resultado.png")
