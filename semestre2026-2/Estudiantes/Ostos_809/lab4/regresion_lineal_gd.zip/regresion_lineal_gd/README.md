# regresion-lineal-gd

Pequeña librería educativa para ajustar una **regresión lineal simple**

    h(x) = θ₀ + θ₁ x

minimizando la **función de coste cuadrática** con **gradiente descendente**.
Desarrollada para el Laboratorio 4 (Regresión lineal y gradiente descendente) del curso de Aprendizaje Estadístico.

## Instalación

Requiere Python ≥ 3.9. Desde la carpeta que contiene `pyproject.toml`:

```bash
# instalación normal
pip install .

# o en modo editable (recomendado si va a modificar el código)
pip install -e .

# con las dependencias para correr el ejemplo y los tests
pip install -e ".[ejemplos,test]"
```

En Google Colab, suba la carpeta (o el `.zip`) y ejecute:

```python
!unzip -q regresion_lineal_gd.zip
!pip install -q ./regresion_lineal_gd
```

## Uso rápido

```python
import numpy as np
from regresion_lineal_gd import fit

X = np.linspace(0, 1, 100)
y = 0.2 + 0.2 * X + 0.02 * np.random.random(100)

res = fit(X, y, alpha=0.5, n_iter=50_000)
print(res.theta0, res.theta1, res.cost)
y_pred = res.predict([0.25, 0.5])
```

Ejemplo completo: [`examples/ejemplo_uso.py`](examples/ejemplo_uso.py).
Documentación detallada: [`docs/USO.md`](docs/USO.md).

## Tests

```bash
pip install -e ".[test]"
pytest
```

## Estructura

```
regresion_lineal_gd/
├── pyproject.toml
├── README.md
├── docs/USO.md
├── examples/ejemplo_uso.py
├── src/regresion_lineal_gd/
│   ├── __init__.py
│   └── core.py
└── tests/test_core.py
```
