# Documentación de uso

## Fundamento

Modelo: `h(x) = θ₀ + θ₁ x`.
Coste: `J(θ) = 1/(2m) Σ (h(xᵢ) − yᵢ)²`.
Gradiente:

- `∂J/∂θ₀ = (1/m) Σ (h(xᵢ) − yᵢ)`
- `∂J/∂θ₁ = (1/m) Σ (h(xᵢ) − yᵢ) xᵢ`

Regla de actualización: `θ := θ − α ∇J(θ)`.

## API

### `hypothesis(X, theta)`
Calcula `θ₀ + θ₁·X`.
- `X`: array_like. `theta`: `(θ₀, θ₁)`.
- Devuelve un `ndarray` con las predicciones.

### `cost_function(X, y, theta)`
Calcula `J(θ)`. Lanza `ValueError` si `X` e `y` difieren en longitud.
- Devuelve un `float`.

### `compute_gradient(X, y, theta)`
Devuelve `np.array([∂J/∂θ₀, ∂J/∂θ₁])`.

### `gradient_descent(X, y, theta_init=None, alpha=0.1, n_iter=10000, tol=1e-10)`
Gradiente descendente por lotes.
- `theta_init`: punto inicial (por defecto `(0, 0)`).
- `alpha`: tasa de aprendizaje (> 0).
- `n_iter`: máximo de iteraciones.
- `tol`: criterio de parada sobre la norma del gradiente.
- Devuelve `(theta, cost_history, theta_history)`.
- Emite `RuntimeWarning` y se detiene si el coste deja de ser finito (α demasiado grande).

### `fit(X, y, alpha=0.1, n_iter=10000, tol=1e-10, theta_init=None)`
Función principal. Devuelve un `FitResult` con:
- `theta0`, `theta1`, `theta`: parámetros ajustados.
- `cost`: coste final. `n_iter`: iteraciones realizadas.
- `cost_history`, `theta_history`: historiales para graficar.
- `predict(X)`: predicciones para nuevos datos.

## Recomendaciones

- Si `X` tiene una escala grande, normalícela antes de ajustar; de lo contrario `α` debe ser muy pequeña.
- Si el coste crece o aparece el aviso de divergencia, reduzca `α`.
- Graficar `cost_history` permite verificar que J disminuye monótonamente.
