"""regresion_lineal_gd: regresión lineal simple por gradiente descendente."""

from .core import (
    FitResult,
    compute_gradient,
    cost_function,
    fit,
    gradient_descent,
    hypothesis,
)

__all__ = [
    "FitResult",
    "hypothesis",
    "cost_function",
    "compute_gradient",
    "gradient_descent",
    "fit",
]
__version__ = "0.1.0"
