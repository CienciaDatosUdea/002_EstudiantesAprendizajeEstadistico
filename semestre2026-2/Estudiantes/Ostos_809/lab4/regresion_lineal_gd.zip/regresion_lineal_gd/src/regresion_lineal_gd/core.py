"""Núcleo de la librería: hipótesis, coste, gradiente y ajuste.

Modelo:        h(x) = theta0 + theta1 * x
Coste:         J(theta) = 1/(2m) * sum_i (h(x_i) - y_i)^2
Actualización: theta := theta - alpha * grad J(theta)
"""

from __future__ import annotations

import warnings
from dataclasses import dataclass, field
from typing import Optional, Sequence

import numpy as np


# ----------------------------------------------------------------------
# Utilidades internas
# ----------------------------------------------------------------------
def _as_1d(a, name: str) -> np.ndarray:
    """Convierte la entrada a un arreglo 1D de floats."""
    arr = np.asarray(a, dtype=float).ravel()
    if arr.size == 0:
        raise ValueError(f"'{name}' no puede estar vacío.")
    return arr


def _check_xy(X, y):
    X = _as_1d(X, "X")
    y = _as_1d(y, "y")
    if X.shape != y.shape:
        raise ValueError(
            f"X e y deben tener la misma longitud (X: {X.size}, y: {y.size})."
        )
    return X, y


# ----------------------------------------------------------------------
# 1. Hipótesis
# ----------------------------------------------------------------------
def hypothesis(X, theta: Sequence[float]) -> np.ndarray:
    """Calcula la hipótesis lineal h(X) = theta0 + theta1 * X.

    Parameters
    ----------
    X : array_like
        Valores de la variable predictora.
    theta : sequence of float
        Parámetros ``(theta0, theta1)``.

    Returns
    -------
    numpy.ndarray
        Predicciones del modelo, con la misma forma que ``X``.
    """
    theta = np.asarray(theta, dtype=float).ravel()
    if theta.size != 2:
        raise ValueError("theta debe contener exactamente dos valores (theta0, theta1).")
    X = np.asarray(X, dtype=float)
    return theta[0] + theta[1] * X


# ----------------------------------------------------------------------
# 2. Función de coste
# ----------------------------------------------------------------------
def cost_function(X, y, theta: Sequence[float]) -> float:
    """Calcula el coste cuadrático J(theta) = 1/(2m) * sum (h(x) - y)^2.

    Parameters
    ----------
    X, y : array_like
        Datos de entrenamiento (misma longitud ``m``).
    theta : sequence of float
        Parámetros ``(theta0, theta1)``.

    Returns
    -------
    float
        Valor del coste.
    """
    X, y = _check_xy(X, y)
    m = y.size
    error = hypothesis(X, theta) - y
    return float(np.sum(error**2) / (2.0 * m))


def compute_gradient(X, y, theta: Sequence[float]) -> np.ndarray:
    """Gradiente de J respecto a ``(theta0, theta1)``.

    dJ/dtheta0 = 1/m * sum (h - y)
    dJ/dtheta1 = 1/m * sum (h - y) * x

    Returns
    -------
    numpy.ndarray
        Arreglo ``[dJ/dtheta0, dJ/dtheta1]``.
    """
    X, y = _check_xy(X, y)
    m = y.size
    error = hypothesis(X, theta) - y
    return np.array([np.sum(error) / m, np.sum(error * X) / m])


# ----------------------------------------------------------------------
# 3. Gradiente descendente
# ----------------------------------------------------------------------
def gradient_descent(
    X,
    y,
    theta_init: Optional[Sequence[float]] = None,
    alpha: float = 0.1,
    n_iter: int = 10_000,
    tol: float = 1e-10,
):
    """Ejecuta gradiente descendente por lotes (batch).

    Parameters
    ----------
    X, y : array_like
        Datos de entrenamiento.
    theta_init : sequence of float, optional
        Valor inicial de ``(theta0, theta1)``. Por defecto ``(0, 0)``.
    alpha : float
        Tasa de aprendizaje (> 0).
    n_iter : int
        Número máximo de iteraciones.
    tol : float
        Se detiene cuando la norma del gradiente es menor que ``tol``.

    Returns
    -------
    theta : numpy.ndarray
        Parámetros finales.
    cost_history : numpy.ndarray
        Coste en cada iteración (incluye el coste inicial).
    theta_history : numpy.ndarray
        Trayectoria de los parámetros, forma ``(k + 1, 2)``.
    """
    X, y = _check_xy(X, y)
    if alpha <= 0:
        raise ValueError("alpha debe ser mayor que 0.")
    if n_iter < 1:
        raise ValueError("n_iter debe ser al menos 1.")

    theta = np.zeros(2) if theta_init is None else np.asarray(theta_init, float).copy()
    if theta.size != 2:
        raise ValueError("theta_init debe contener dos valores.")

    cost_history = [cost_function(X, y, theta)]
    theta_history = [theta.copy()]

    for _ in range(n_iter):
        grad = compute_gradient(X, y, theta)
        if np.linalg.norm(grad) < tol:
            break
        theta = theta - alpha * grad
        cost = cost_function(X, y, theta)
        if not np.isfinite(cost):
            warnings.warn(
                "El coste dejó de ser finito: el algoritmo diverge. "
                "Reduzca alpha.",
                RuntimeWarning,
                stacklevel=2,
            )
            break
        cost_history.append(cost)
        theta_history.append(theta.copy())

    return theta, np.array(cost_history), np.array(theta_history)


# ----------------------------------------------------------------------
# 4. Función principal de ajuste
# ----------------------------------------------------------------------
@dataclass
class FitResult:
    """Resultado de :func:`fit`."""

    theta0: float
    theta1: float
    cost: float
    n_iter: int
    cost_history: np.ndarray = field(repr=False)
    theta_history: np.ndarray = field(repr=False)

    @property
    def theta(self) -> np.ndarray:
        return np.array([self.theta0, self.theta1])

    def predict(self, X) -> np.ndarray:
        """Predice ``y`` para nuevos valores de ``X``."""
        return hypothesis(X, self.theta)


def fit(
    X,
    y,
    alpha: float = 0.1,
    n_iter: int = 10_000,
    tol: float = 1e-10,
    theta_init: Optional[Sequence[float]] = None,
) -> FitResult:
    """Ajusta ``h(x) = theta0 + theta1 * x`` minimizando J con gradiente descendente.

    Example
    -------
    >>> import numpy as np
    >>> X = np.linspace(0, 1, 50)
    >>> y = 1.0 + 3.0 * X
    >>> res = fit(X, y, alpha=0.5, n_iter=20000)
    >>> round(res.theta1, 2)
    3.0
    """
    theta, cost_hist, theta_hist = gradient_descent(
        X, y, theta_init=theta_init, alpha=alpha, n_iter=n_iter, tol=tol
    )
    return FitResult(
        theta0=float(theta[0]),
        theta1=float(theta[1]),
        cost=float(cost_hist[-1]),
        n_iter=len(cost_hist) - 1,
        cost_history=cost_hist,
        theta_history=theta_hist,
    )
